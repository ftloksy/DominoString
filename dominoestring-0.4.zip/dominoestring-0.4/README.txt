Dominoes String
====================

Entry in PyWeek #7  <http://www.pyweek.org/7/>
Members: Milker

DEPENDENCIES:

You might need to install some of these before running the game:

  Python:     http://www.python.org/
  PyGame:     http://www.pygame.org/


RUNNING THE GAME:

On Windows or Mac OS X, locate the "run_game.pyw" file and double-click it.

Othewise open a terminal / console and "cd" to the game directory and run:

  python run_game.py



HOW TO PLAY THE GAME:

Move the cursor around the screen with the mouse.

Press the left mouse button to move the dominoes.

Press the right mouse button to turn the dominoes.

Please move the dominoes to the red holder,

and turn the right face.

Keep the line like TIP (in Main screen top).


LICENSE:

This game and sound is placed in the GPLv2.
